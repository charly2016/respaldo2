<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_ecf3e4f8f34a293099620cc25d5b4d93'] = 'Bloque Mi cuenta';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_ecf2ffd31994b3edea4b916011b08bfa'] = 'Mostrar un bloque con enlaces a la cuenta del usuario';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mi cuenta';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_74ecd9234b2a42ca13e775193f391833'] = 'Mis compras';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_89080f0eedbd5491a93157930f1e45fc'] = 'Mis devoluciones';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_9132bc7bac91dd4e1c453d4e96edf219'] = 'Mis vales descuento';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Mis direcciones';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_63b1ba91576576e6cf2da6fab7617e58'] = 'Mis datos personales';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_95d2137c196c7f84df5753ed78f18332'] = 'Mis vales';
$_MODULE['<{blockmyaccount}prestashop>blockmyaccount_c87aacf5673fada1108c9f809d354311'] = 'Cerrar sesión';


return $_MODULE;
