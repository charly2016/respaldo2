<?php

$fixtures = array(
	"CUSTPRIV_MSG_AUTH" => array(
		'fr-fr' => "Conformément aux dispositions de la loi du n°78-17 du 6 janvier 1978, vous disposez d'un droit d'accès, de rectification et d'opposition sur les données nominatives vous concernant.",
	),
	"CUSTPRIV_MSG_IDENTITY" => array(
		'fr-fr' => "Conformément aux dispositions de la loi du n°78-17 du 6 janvier 1978, vous disposez d'un droit d'accès, de rectification et d'opposition sur les données nominatives vous concernant.",
	),
);