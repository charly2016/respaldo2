<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockbanner}prestashop>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloque de Banner';
$_MODULE['<{blockbanner}prestashop>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Muestra un banner en la parte superior de la tienda.';
$_MODULE['<{blockbanner}prestashop>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Se ha producido un error durante el envío.';
$_MODULE['<{blockbanner}prestashop>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'La configuración ha sido actualizada.';
$_MODULE['<{blockbanner}prestashop>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockbanner}prestashop>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Imagen del Banner Superior';
$_MODULE['<{blockbanner}prestashop>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Cargar una imagen para su banner superior. Las dimensiones recomendadas son 1170 x 65px si está utilizando el tema por defecto.';
$_MODULE['<{blockbanner}prestashop>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Enlace del Banner';
$_MODULE['<{blockbanner}prestashop>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Introduzca el enlace asociado a su banner. Al hacer clic sobre el banner, se abre en la misma ventana el enlace. Si no introduce ningún enlace, redirige a la página de inicio.';
$_MODULE['<{blockbanner}prestashop>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Descripción del banner';
$_MODULE['<{blockbanner}prestashop>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Por favor, introduzca una descripción breve pero significativa para el banner.';
$_MODULE['<{blockbanner}prestashop>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockbanner}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Elegir un fichero';


return $_MODULE;
