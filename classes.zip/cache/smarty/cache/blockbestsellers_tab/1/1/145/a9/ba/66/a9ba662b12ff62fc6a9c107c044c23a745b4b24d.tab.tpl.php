<?php /*%%SmartyHeaderCode:1080357ab5b65188be5-65004011%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a9ba662b12ff62fc6a9c107c044c23a745b4b24d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\modules\\blockbestsellers\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1080357ab5b65188be5-65004011',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b65188be8_65955880',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b65188be8_65955880')) {function content_57ab5b65188be8_65955880($_smarty_tpl) {?><li><a data-toggle="tab" href="#blockbestsellers" class="blockbestsellers">Los más vendidos</a></li><?php }} ?>
