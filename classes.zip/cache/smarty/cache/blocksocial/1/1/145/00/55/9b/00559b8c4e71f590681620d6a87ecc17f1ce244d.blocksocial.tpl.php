<?php /*%%SmartyHeaderCode:1612257ab5b65c01ff6-09484942%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '00559b8c4e71f590681620d6a87ecc17f1ce244d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\themes\\default-bootstrap\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1466020874,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1612257ab5b65c01ff6-09484942',
  'variables' => 
  array (
    'facebook_url' => 0,
    'twitter_url' => 0,
    'rss_url' => 0,
    'youtube_url' => 0,
    'google_plus_url' => 0,
    'pinterest_url' => 0,
    'vimeo_url' => 0,
    'instagram_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b65cb8cf9_05379325',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b65cb8cf9_05379325')) {function content_57ab5b65cb8cf9_05379325($_smarty_tpl) {?><section id="social_block" class="pull-right">
	<ul>
					<li class="facebook">
				<a class="_blank" href="http://www.facebook.com/prestashop">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a class="_blank" href="http://www.twitter.com/prestashop">
					<span>Twitter</span>
				</a>
			</li>
							<li class="rss">
				<a class="_blank" href="http://www.prestashop.com/blog/en/">
					<span>RSS</span>
				</a>
			</li>
		                        	<li class="google-plus">
        		<a class="_blank" href="https://www.google.com/+prestashop" rel="publisher">
        			<span>Google Plus</span>
        		</a>
        	</li>
                                	</ul>
    <h4>Síganos</h4>
</section>
<div class="clearfix"></div>
<?php }} ?>
