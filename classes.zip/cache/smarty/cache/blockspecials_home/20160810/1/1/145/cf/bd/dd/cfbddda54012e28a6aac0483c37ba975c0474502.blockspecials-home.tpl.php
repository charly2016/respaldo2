<?php /*%%SmartyHeaderCode:3203757ab5b65ad14f5-47254823%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cfbddda54012e28a6aac0483c37ba975c0474502' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\modules\\blockspecials\\views\\templates\\hook\\blockspecials-home.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
    'd112d10f9a7d63a1e2bbbfda4fa66f18e0ed8a8d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\themes\\default-bootstrap\\product-list.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3203757ab5b65ad14f5-47254823',
  'variables' => 
  array (
    'specials' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b65b0e3f0_03260018',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b65b0e3f0_03260018')) {function content_57ab5b65b0e3f0_03260018($_smarty_tpl) {?>		
									
		
	
	<!-- Products list -->
	<ul id="blockspecials" class="product_list grid row blockspecials tab-pane">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html" title="Vestido de verano estampado" itemprop="url">
							<img class="replace-2x img-responsive" src="http://localhost/tienda2/12-home_default/vestido-verano-estampado.jpg" alt="Vestido de verano estampado" title="Vestido de verano estampado"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html" rel="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html" rel="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html">
							<span>Vista r&aacute;pida</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										33,62 $									</span>
									<meta itemprop="priceCurrency" content="MXN" />
																			
										<span class="old-price product-price">
											35,39 $
										</span>
																					<span class="price-percent-reduction">-5%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />En stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html">
								<span class="new-label">Nuevo</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html" title="Vestido de verano estampado" itemprop="url" >
							Vestido de verano estampado
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Vestido largo estampado con tirantes finos ajustables. Escote en V, fruncido debajo del pecho y volantes en la parte inferior del vestido.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								33,62 $							</span>
															
								<span class="old-price product-price">
									35,39 $
								</span>
								
																	<span class="price-percent-reduction">-5%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://localhost/tienda2/carrito?add=1&amp;id_product=5&amp;ipa=19&amp;token=91ace9ea6c19677b275f662b9d215cf2" rel="nofollow" title="A&ntilde;adir al carrito" data-id-product-attribute="19" data-id-product="5" data-minimal_quantity="1">
									<span>A&ntilde;adir al carrito</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://localhost/tienda2/vestidos-verano/5-vestido-verano-estampado.html" title="Ver">
							<span>M&aacute;s</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">&iexcl;Precio rebajado!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										En stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html" title="Vestido de gasa estampado" itemprop="url">
							<img class="replace-2x img-responsive" src="http://localhost/tienda2/20-home_default/vestido-estampado-gasa.jpg" alt="Vestido de gasa estampado" title="Vestido de gasa estampado"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html" rel="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html" rel="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html">
							<span>Vista r&aacute;pida</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										19,03 $									</span>
									<meta itemprop="priceCurrency" content="MXN" />
																			
										<span class="old-price product-price">
											23,78 $
										</span>
																					<span class="price-percent-reduction">-20%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />En stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html">
								<span class="new-label">Nuevo</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html" title="Vestido de gasa estampado" itemprop="url" >
							Vestido de gasa estampado
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Vestido sin mangas hasta la rodilla, tejido de gasa estampado. Escote pronunciado.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								19,03 $							</span>
															
								<span class="old-price product-price">
									23,78 $
								</span>
								
																	<span class="price-percent-reduction">-20%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://localhost/tienda2/carrito?add=1&amp;id_product=7&amp;ipa=34&amp;token=91ace9ea6c19677b275f662b9d215cf2" rel="nofollow" title="A&ntilde;adir al carrito" data-id-product-attribute="34" data-id-product="7" data-minimal_quantity="1">
									<span>A&ntilde;adir al carrito</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://localhost/tienda2/vestidos-verano/7-vestido-estampado-gasa.html" title="Ver">
							<span>M&aacute;s</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">&iexcl;Precio rebajado!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										En stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>
