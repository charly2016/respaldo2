<?php /*%%SmartyHeaderCode:1278457ab5b652b96e3-71680202%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '50597ba309f3a8f4ca8d72acc0ca85395b4eace5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\modules\\blockspecials\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1278457ab5b652b96e3-71680202',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b652b96e8_74918772',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b652b96e8_74918772')) {function content_57ab5b652b96e8_74918772($_smarty_tpl) {?><li><a data-toggle="tab" href="#blockspecials" class="blockspecials">Promociones especiales</a></li>
<?php }} ?>
