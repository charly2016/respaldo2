<?php /*%%SmartyHeaderCode:343757ab5b64c452d7-35455865%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fafc8e7b1819864d1cd2fe565c88f520a6d48db1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\modules\\blocknewproducts\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '343757ab5b64c452d7-35455865',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b64c821d7_02776331',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b64c821d7_02776331')) {function content_57ab5b64c821d7_02776331($_smarty_tpl) {?><li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts">Nuevos</a></li>
<?php }} ?>
