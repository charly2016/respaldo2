<?php /*%%SmartyHeaderCode:1122957ab5b66a51311-25115359%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5da45eab5d2af20bccaf4dd11eef300037850823' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\themes\\default-bootstrap\\modules\\blockcontact\\nav.tpl',
      1 => 1466020874,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1122957ab5b66a51311-25115359',
  'variables' => 
  array (
    'is_logged' => 0,
    'link' => 0,
    'telnumber' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b66a8e214_35919320',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b66a8e214_35919320')) {function content_57ab5b66a8e214_35919320($_smarty_tpl) {?><div id="contact-link" >
	<a href="http://localhost/tienda2/contactanos" title="Contacte con nosotros">Contacte con nosotros</a>
</div>
	<span class="shop-phone">
		<i class="icon-phone"></i>Llámanos ahora: <strong>0123-456-789</strong>
	</span>
<?php }} ?>
