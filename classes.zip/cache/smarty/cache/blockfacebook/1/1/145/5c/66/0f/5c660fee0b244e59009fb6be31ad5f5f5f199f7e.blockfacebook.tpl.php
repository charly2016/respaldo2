<?php /*%%SmartyHeaderCode:2754357ab5b643398c5-24477600%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5c660fee0b244e59009fb6be31ad5f5f5f199f7e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\modules\\blockfacebook\\blockfacebook.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2754357ab5b643398c5-24477600',
  'variables' => 
  array (
    'facebookurl' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b643b36c4_14536374',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b643b36c4_14536374')) {function content_57ab5b643b36c4_14536374($_smarty_tpl) {?><div id="fb-root"></div>
<div id="facebook_block" class="col-xs-4">
	<h4 >Síguenos en Facebook</h4>
	<div class="facebook-fanbox">
		<div class="fb-like-box" data-href="https://www.facebook.com/prestashop" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false">
		</div>
	</div>
</div>
<?php }} ?>
