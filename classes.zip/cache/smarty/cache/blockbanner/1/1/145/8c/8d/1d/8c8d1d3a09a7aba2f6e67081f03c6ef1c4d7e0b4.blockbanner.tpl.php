<?php /*%%SmartyHeaderCode:2142857ab5b668e3913-01018862%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c8d1d3a09a7aba2f6e67081f03c6ef1c4d7e0b4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\modules\\blockbanner\\blockbanner.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2142857ab5b668e3913-01018862',
  'variables' => 
  array (
    'banner_link' => 0,
    'force_ssl' => 0,
    'base_dir_ssl' => 0,
    'base_dir' => 0,
    'banner_desc' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b6695d710_86702070',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b6695d710_86702070')) {function content_57ab5b6695d710_86702070($_smarty_tpl) {?><a href="http://localhost/tienda2/" title="">
	<img class="img-responsive" src="http://localhost/tienda2/modules/blockbanner/img/sale70.png" alt="" title="" width="1170" height="65" />
</a>
<?php }} ?>
