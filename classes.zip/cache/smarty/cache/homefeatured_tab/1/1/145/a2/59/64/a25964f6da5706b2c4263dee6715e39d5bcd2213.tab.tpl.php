<?php /*%%SmartyHeaderCode:758657ab5b64e2cae9-75722426%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a25964f6da5706b2c4263dee6715e39d5bcd2213' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\modules\\homefeatured\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '758657ab5b64e2cae9-75722426',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab5b64ea68e9_71304911',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab5b64ea68e9_71304911')) {function content_57ab5b64ea68e9_71304911($_smarty_tpl) {?><li><a data-toggle="tab" href="#homefeatured" class="homefeatured">Populares</a></li><?php }} ?>
