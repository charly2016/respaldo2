<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 18:10:15
         compiled from "C:\xampp\htdocs\tienda2\themes\default-bootstrap\modules\blockuserinfo\blockuserinfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:545357ab51e792d7f9-74920540%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1171acbfe291cf57fcaf57bb3a0ea40bd6548079' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\themes\\default-bootstrap\\modules\\blockuserinfo\\blockuserinfo.tpl',
      1 => 1466020874,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '545357ab51e792d7f9-74920540',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab51e792d7f8_97972653',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab51e792d7f8_97972653')) {function content_57ab51e792d7f8_97972653($_smarty_tpl) {?><?php }} ?>
