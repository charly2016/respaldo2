<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 18:10:16
         compiled from "C:\xampp\htdocs\tienda2\themes\default-bootstrap\modules\productcomments\productcomments_top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1250857ab51e89c22b5-73692071%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0d661f74efc37803a5be634e51e70d14d8f9ad16' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\themes\\default-bootstrap\\modules\\productcomments\\productcomments_top.tpl',
      1 => 1466020874,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1250857ab51e89c22b5-73692071',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab51e89c22b1_60787234',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab51e89c22b1_60787234')) {function content_57ab51e89c22b1_60787234($_smarty_tpl) {?><?php }} ?>
