<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 18:10:14
         compiled from "C:\xampp\htdocs\tienda2\themes\default-bootstrap\modules\blocklayered\blocklayered-no-products.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1605257ab51e6ecadb1-03564412%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0c725129339b6c8786ab54fe33ecdecdf153e01b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda2\\themes\\default-bootstrap\\modules\\blocklayered\\blocklayered-no-products.tpl',
      1 => 1466020874,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1605257ab51e6ecadb1-03564412',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab51e6ecec32_76386735',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab51e6ecec32_76386735')) {function content_57ab51e6ecec32_76386735($_smarty_tpl) {?>
<div class="product_list">
	<p class="alert alert-warning"><?php echo smartyTranslate(array('s'=>'There are no products.','mod'=>'blocklayered'),$_smarty_tpl);?>
</p>
</div>
<?php }} ?>
