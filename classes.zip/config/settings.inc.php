<?php
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'prestashop2');
define('_DB_USER_', 'root');
define('_DB_PASSWD_', '');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheMemcache');
define('_PS_CACHE_ENABLED_', '0');
define('_COOKIE_KEY_', '1LKgrkBKv7Cnmc0EEaAbT9gn4PPV72MMouxVb79TvzHTYJDT1XVZ5HOJ');
define('_COOKIE_IV_', '611z8GjU');
define('_PS_CREATION_DATE_', '2016-08-10');
if (!defined('_PS_VERSION_'))
	define('_PS_VERSION_', '1.6.1.6');
define('_RIJNDAEL_KEY_', 'EihjBP0eem46WBoD4CJXmiCp4v1y766w');
define('_RIJNDAEL_IV_', 'LJsH1ooFgXNLZiFbVUeP1g==');
